<?php
	include_once"includes/header.php";
?>


<table style="border-collapse: collapse;width: 100%">
		<tr>
			
			<th>Student Name</th>
			<th>Student ID</th>
			<th>Email</th>
			
		</tr>
		
			<tr>
				
				<td>Fazal Mahmud Niloy</td>
				<td>1321579042</td>
				<td>niloooy@gmail.com</td>
				
			</tr>
			<tr>
				
				<td>Md. Sakibul Alam</td>
				<td>1420604042</td>
				<td>sakibul.alam@northsouth.edu</td>
				
			</tr>
			<tr>
				
				<td>Ashikur Rahman</td>
				<td>1321409042</td>
				<td>Ashikur.rahman13@northsouth.edu</td>
				
			</tr>

		<style>
			table {
			    border-collapse: collapse;
			    width: 100%;
			}

			th, td {
			    padding: 8px;
			    text-align: left;
			    border-bottom: 1px solid #ddd;
			}

			tr:hover{background-color:#f5f5f5}
		</style>
	</table>



	</div> 

	</body>
</html>