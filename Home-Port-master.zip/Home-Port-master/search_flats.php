<?php
	 	include_once "includes/header.php";
	 	include_once "connection.php";

?>


<h2 align="center">Search your desired flats.</h2>



 </div> 

	</body>
</html>